package com.emovie.model;

public class Show {
	private String shid,movienm,city,theaternm,strttime,endtime,date;
	private int screen,seat,platinumrt,goldrt,silverrt;
	public String getShid() {
		return shid;
	}
	public void setShid(String shid) {
		this.shid = shid;
	}
	public String getMovienm() {
		return movienm;
	}
	public void setMovienm(String movienm) {
		this.movienm = movienm;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getTheaternm() {
		return theaternm;
	}
	public void setTheaternm(String theaternm) {
		this.theaternm = theaternm;
	}
	public String getStrttime() {
		return strttime;
	}
	public void setStrttime(String strttime) {
		this.strttime = strttime;
	}
	public String getEndtime() {
		return endtime;
	}
	public void setEndtime(String endtime) {
		this.endtime = endtime;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public int getScreen() {
		return screen;
	}
	public void setScreen(int screen) {
		this.screen = screen;
	}
	public int getSeat() {
		return seat;
	}
	public void setSeat(int seat) {
		this.seat = seat;
	}
	public int getPlatinumrt() {
		return platinumrt;
	}
	public void setPlatinumrt(int platinumrt) {
		this.platinumrt = platinumrt;
	}
	public int getGoldrt() {
		return goldrt;
	}
	public void setGoldrt(int goldrt) {
		this.goldrt = goldrt;
	}
	public int getSilverrt() {
		return silverrt;
	}
	public void setSilverrt(int silverrt) {
		this.silverrt = silverrt;
	}
	
	

}
